import xlrd
import xlwt
import os
import re
import codecs
import time
import jieba
import jieba.analyse
from textrank4zh import TextRank4Keyword, TextRank4Sentence


def load_stop_word(context):
    location = os.getcwd()
    for word in open(os.path.join(location,'stopwords.txt'),'r',encoding="utf-8"):
        context.append(word.strip())
    return context

def read_excel():
    #open the data(1).xls
    location = os.getcwd()
    excel_data = xlrd.open_workbook(os.path.join(location,'data(1).xls'))
    wb = xlwt.Workbook()
    user_result = input("how many keyword you want to output:  ")
    for sheet in excel_data.sheet_names():
        #iterate the sheet of the xls file
        one_of_the_sheet = excel_data.sheet_by_name(sheet)
        output_result =  wb.add_sheet(sheet+"textrank_result", cell_overwrite_ok=True)
        row_num = one_of_the_sheet.nrows
        #the total row of one sheet
        
        new_data_list = {}
        for i in range(row_num):
            new_data_list = {}
            data_list = {}
            data__ = ""

            data = ""
            cell_data = one_of_the_sheet.cell(i,0)
            #iterate to got the cell value
            filter_data = re.findall(r"text:'(.*?)'",str(cell_data))
            #regular expression to filter text:'xxx'
            if filter_data  :
                #if the cell is not null
                data__ += str(filter_data[0])

            words = jieba.cut(data__,cut_all=False)
            
            for word in words:
                data += word
                #the row of data
            #chinese word cut
            data_list = textrank(data, data_list)

            if data:
                data = None
            #textrank algorithm

            key_list = []
        #store the value of to data_list dict
            value_list = []
            #store the key of to data_list dict

            
            for k, v in data_list.items():
                
                value_list.append(v)
                key_list.append(k)
                new_data_list[k] = v

            if int(user_result) > len(key_list):
                print("maximum : %s "%len(key_list))
                time.sleep(3)
                for key in range(0,len(key_list)):
                    print('key: {}, index: {}'.format(key_list[key], new_data_list[key_list[key]]))
                    col = (key+1)**2
                    output_result.write(i, 0, filter_data)
                    output_result.write(i, col, key_list[key])
                    output_result.write(i, col+1, new_data_list[key_list[key]])
                    
                    
            else:
                for key in range(0,int(user_result)):
                    print('key: {}, index: {}'.format(key_list[key], new_data_list[key_list[key]]))
                    col = (key+1)**2
                    output_result.write(i, 0, filter_data)
                    output_result.write(i, col, key_list[key])
                    output_result.write(i, col+1, new_data_list[key_list[key]])
                
            wb.save("data_textrank_result.xls")

   
        print()
        print()
    wb.save("data_textrank_result.xls") 
        

def textrank(context, list):
    tr4w = TextRank4Keyword(stop_words_file='./stopwords.txt')
    tr4w.analyze(text=context, lower=True, window=2)
    
    
    for item in tr4w.get_keywords(5, word_min_len=1):
        list[item.weight] = item.word
    return list


if __name__ == "__main__":
    read_excel()















